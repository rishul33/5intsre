<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112747299-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112747299-1');
</script>

<!-- Global site tag (gtag.js) - Google Ads: 771280886 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-771280886"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-771280886');
</script>

<title>ITES Staffing Services | ITES Staffing Company | Agency | Pune | Mumbai |Bengaluru| Talensetu</title>

<meta name="description" content="Several ITES staffing services in India provide different candidates for this rapidly growing industry. The ITES staffing company need to provide industry ready candidates who are familiar with industry skills. The ITES company are looking for tech-savvy as well as multi-skilled people." />

<meta name="keywords" content="ITES staffing services in pune, ITES staffing services in mumbai, ITES staffing services in Bengaluru, ITES staffing companies in pune, ITES staffing companies in mumbai,ITES staffing companies in Bengaluru, ITES staffing agency in pune, ITES staffing agency in mumbai,ITES staffing agency in Bengaluru, IT staffing services in mumbai, IT staffing services in Bengaluru,IT staffing company in pune, IT staffing company in mumbai,IT staffing company in Bengaluru, IT staffing agency in pune, IT staffing agency in mumbai,IT staffing agency in Bengaluru, payroll services in pune,payroll services in mumbai,payroll services in Bengaluru, payroll outsourcing company in pune, payroll outsourcing company in mumbai,payroll outsourcing company in  Bengaluru, payroll outsourcing services in pune, payroll outsourcing services in mumbai,payroll outsourcing services in Bengaluru, payroll outsourcing services company in pune, payroll outsourcing services company in mumbai,  payroll outsourcing services company in Bengaluru,payroll management services in pune, payroll management services in mumbai,payroll management services in Bengaluru,  payroll service providers in pune, payroll service providers in mumbai,payroll service providers in Bengaluru, temporary employment agencies, employment staffing agencies, contract staffing services, contract staffing solutions, employee leasing services in india, employee leasing solutions, payroll services, payroll processing companies, payroll service providers, best payroll service for small business, payroll management company, staff augmentation services in india, temporary staffing solutions in pune, temporary staffing solutions in mumbai, temporary staffing solutions in Bengaluru,temporary staffing services in pune, temporary staffing services in mumbai,temporary staffing services in Bengaluru, temporary staffing agency in pune, temporary staffing agency in mumbai,temporary staffing agency in  Bengaluru, temp staffing companies in pune, temp staffing companies in mumbia, temp staffing companies in Bengaluru ,contract staffing services in pune, contract staffing services in mumbai,contract staffing services in Bengaluru, IT staffing services in pune" />




<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" href="favicon.ico" type="image/x-icon">
<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700|Nunito+Sans:400,600" rel="stylesheet">
<!-- Bootstrap -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<link href="css/validation/validation.css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<header>
<div class="topHeader">
  <div class="container-fluid">
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-sm-4 col-xs-5 logoWrap"> 
				<a class="navbar-brand" href="index.php" title="Talensetu"><img src="images/talensetu-logo.png" alt="Talensetu"></a> 
			</div><br>
			<div class="col-md-6 col-sm-8 col-xs-7 regiWrap">
				<ul class="list-inline" style="text-align: right;"> 
					<li><a href="tel:9595637970"  onClick="gtag('event', 'Call', { event_category: 'Click Call', event_action: 'Call'});">Domestic <i class="fa fa-phone"></i>  +91 95 95 63 79 70</a></li>
					<br>
					<li><a href="tel:9545397970" onClick="gtag('event', 'Call', { event_category: 'Click Call', event_action: 'Call'});" >International <i class="fa fa-globe" aria-hidden="true"></i> +91 91 12 20 07 91</a></li>
					<!--<li><a href="info@talensetustaffing.com"><i class="fa fa-envelope"></i> &nbsp; info@talensetustaffing.com</a></li>	-->
				</ul>
			</div>
		</div>
	</div>
</div>

</div>

<div class="homeBanner">
   <nav class="navbar navbar-default mainNav">
  <div class="container-fluid">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
    </div>
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li ><a href="index.php">Home</a></li>
        <li ><a href="about-us.php">About Us</a></li>
      <!--  <li class="dropdown"  id="" >
        <a href="" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Domestic<span class="glyphicon glyphicon-menu-down" aria-hidden="true" style="font-size: 14px;margin-left: 5px;"></span></a>
        <ul class="dropdown-menu">
		 <div class="row ">
		  <div class="column">
			 <a href="services-landing.php"><h4 style="color: #000033;  text-decoration: underline;">Services</h4></a>
              <span class="fa fa-chevron-right"><a href="temporary-staffing-services.php"  > Temporary Staffing</a></span>
              <span class="fa fa-chevron-right"><a href="permanent-staffing.php"  >Permanent Staffing</a></span>
			  <span class="fa fa-chevron-right"><a href="contract-staffing.php"  >Contract Staffing</a></span>
			  <span class="fa fa-chevron-right"><a href="contract-to-hire-staffing.php"  >Contract to Hire</a></span>
			  <span class="fa fa-chevron-right"><a href="RPO.php"  > RPO</a></span>
			  <span class="fa fa-chevron-right"><a href="payroll-outsourcing-services.php"  > Payroll Services</a></span>
			     <span class="fa fa-chevron-right"><a href="Manpower-Supply-Services.php"  > Manpower Supply Services</a></span>
           </div>
		   <div class="column " >
			   <a href="industries-landing.php"><h4 style="color: #000033; text-decoration: underline;">Industry  Sectors</h4></a>
              <span class="fa fa-chevron-right"><a href="it-staffing-services.php"> IT</a></span>
              <span class="fa fa-chevron-right"><a href="ites-suffing-serivces.php"> ITES</a></span>
              <span class="fa fa-chevron-right"><a href="bfsi-staffing-services.php">BFSI</a></span>
              <span class="fa fa-chevron-right"><a href="retail-staffing-services.php">Retail</a></span>
			  <span class="fa fa-chevron-right"><a href="telecom-staffing-services.php">  Telecom</a></span>	
			  <span class="fa fa-chevron-right"><a href="engineering-manufacturing-staffing-services.php"> Engg. Manufacturing</a></span>
           </div>
		  </div>
		</ul>
        </li>-->
		    <li class="dropdown"  id="" >
        <a href="" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Domestic<span class="glyphicon glyphicon-menu-down" aria-hidden="true" style="font-size: 14px;margin-left: 5px;"></span></a>
			<ul class="dropdown-menu">
				<div class="row">
				<div class="column">
				 <a href="services-landing.php"><h4 style="color: #000033;  text-decoration: underline; width: 180px;">Services</h4></a>
				 
				  <span class="fa fa-chevron-right" style="width: 280px;"><a href="Manpower-Supply-Services.php"  > Manpower Supply Services</a></span>
				  <span class="fa fa-chevron-right" style="width: 180px;"><a href="payroll-outsourcing-services.php"  > Payroll Services</a></span>
				   <span class="fa fa-chevron-right" style="width: 180px;"><a href="contract-to-hire-staffing.php"  >Contract to Hire</a></span>
				   <span class="fa fa-chevron-right" style="width: 180px;"><a href="national-apprenticeship-promotion-scheme-naps.php"  >NAPS</a></span>
				   <span class="fa fa-chevron-right" style="width: 200px;"><a href="facility-management-housekeeping-services-pune.php"  >Facility Management Services</a></span>
				  
      <!--       <span class="fa fa-chevron-right" style="width: 200px;"> <a href="temporary-staffing-services.php"  > Temporary Staffing</a></span>-->
      <!--          <span class="fa fa-chevron-right" style="width: 200px;"><a href="permanent-staffing.php"  >Permanent Staffing</a></span>-->
			   <!--<span class="fa fa-chevron-right" style="width: 180px;"><a href="contract-staffing.php"  >Contract Staffing</a></span>-->
			    
			   <!-- <span class="fa fa-chevron-right" style="width: 180px;"><a href="RPO.php"  > RPO</a></span>-->
			  
			     
				 </div>
				 <div class="column" >
				<a href="industries-landing.php"><h4 style="color: #000033;  text-decoration: underline; width: 200px;">Industries We  Serve</h4></a>
				
				
		        <span class="fa fa-chevron-right" ><a href="engineering-manufacturing-staffing-services.php"> Engineering and Manufacturing</a></span>
			    <span class="fa fa-chevron-right" style="width: 200px;"><a href="retail-staffing-services.php">Retail</a></span>
			 	<span class="fa fa-chevron-right" style="width: 200px;"><a href="it-staffing-services.php"> IT</a></span>
                <span class="fa fa-chevron-right" style="width: 200px;"><a href="ites-suffing-serivces.php"> ITES</a></span>
                <span class="fa fa-chevron-right" style="width: 200px;"><a href="bfsi-staffing-services.php">BFSI</a></span>
                <span class="fa fa-chevron-right" style="width: 200px;"><a href="telecom-staffing-services.php">  Telecom</a></span>	
			    <!--<span class="fa fa-chevron-right"  style="width: 200px;"><a href="ITeS-BPO.php">ITeS BPO  </a></span>-->
            
             
			 
				 </div>
			<!--		 <div class="column" >-->
			<!--	<a href="#"><h4 style="color: #000033;  text-decoration: underline; width: 200px;">Positions We Recruit</h4></a>-->
			<!--	<span class="fa fa-chevron-right" ><a href="sales-and-account-manager-recruitment-staffing-agency.php"> Sales & Account Manager </a></span>-->
   <!--           <span class="fa fa-chevron-right" ><a href="field-sales-officer-recruitment-staffing-agency.php"> Field Sales Officer  </a></span>-->
   <!--           <span class="fa fa-chevron-right"  style="width: 200px;"><a href="retail-associate-recruitment-staffing-agency.php">Retail Associate </a></span>-->
   <!--           <span class="fa fa-chevron-right" ><a href="BPO-executive-recruitment-staffing-agency.php">BPO Executive </a></span>-->
			
			
			<!--</span> -->
			<!--	 </div>-->
				</div>
				</ul>
		  </li>
		 <li class="dropdown"  id="" >
	 <a href="" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">International<span class="glyphicon glyphicon-menu-down" aria-hidden="true" style="font-size: 14px;margin-left: 5px;"></span></a>
			<ul class="dropdown-menu">
				<div class="row">
		<!--		<div class="column">-->
			
		<!--		<a href="#" style="font-size:12px;">Keeping in mind every country’s vision of providing employment opportunity for their students or unemployed youth and citizens, Talensetu is offering customized “Employment Oriented Training Programs”.</a><p>-->
		<!--		    <a href="Overseas-Training.php">Read More...</a>-->
		<!--		    </p>-->
		<!--</div>-->
			<div class="column">
		<a href="International-Recruitment.php"><h4 style="color: #000033;  text-decoration: underline;">International Recruitment</h4></a>
		<span class="fa fa-chevron-right">  <a href="Categories-of-Technician.php"  > Categories of Technician</a></span>
			<span class="fa fa-chevron-right"> <a href="Categories-of-Recruitment.php"  > Categories of Recruitment</a></span>
		  <span class="fa fa-chevron-right"> <a href="Civil-Construction-Industry.php"  >Civil Construction Industry</a> </span>
		 <span class="fa fa-chevron-right">   <a href="Oil-and-Gas-Industry.php"  > Oil and Gas Industry </a></span>
		   <span class="fa fa-chevron-right"> <a href=" Oil-Fields-and-Refinery-Industry.php"  > Oil Fields and Refinery Industry</a></span>
		<span class="fa fa-chevron-right">  <a href="Petrochemical-&-Process-Industry.php"  >Petrochemical & Process Industry</a></span>
		 </div>
		 <div class="column">
		<br><br><br>
         <span class="fa fa-chevron-right"><a href="Manufacturing-Industry.php" >Manufacturing Industry </a></span>
		   <span class="fa fa-chevron-right"><a href="Infrastructure-Industry.php"  >  Infrastructure Industry</a></span>
		   <span class="fa fa-chevron-right"><a href="Power-and-Utility-Industry.php"  >Power and Utility Industry</a></span>
		   <span class="fa fa-chevron-right"><a href="Steel-Fabrication-Industry.php"  > Steel Fabrication Industry</a></span>
		   <span class="fa fa-chevron-right"><a href="Medical-and-Hospital-Industry.php"  >Medical and Hospital Industry</a></span>
		   <span class="fa fa-chevron-right"><a href="Information-Technology.php"  > Information Technology</a></span>
		   
	     </div>
		</div>
		</ul>
       <!-- <ul class="dropdown-menu megamenu">
		 <div class="row">
		  <div class="column">
		    <a href="#"><h4 style="color: #000033;  text-decoration: underline;">Services</h4></a>
			<a href="Overseas-Internship-Program.php" class="fa fa-chevron-right"> &nbsp; Overseas Internship Program</a>
			<a href="Higher-Education-and-Jobs-in-Canada.php" class="fa fa-chevron-right"> &nbsp; Higher Education & Jobs in Canada </a>
			<a href="Study-In-New-Zealand.php" class="fa fa-chevron-right"> &nbsp; Study In New Zealand</a>
            <a href="Curricular-Practical-Training-Program.php" class="fa fa-chevron-right"> &nbsp; Curricular Practical Training</a>
            <a href="GCC-countries.php" class="fa fa-chevron-right"> &nbsp;GCC & Region Staffing & Recruitment</a>
			<!--<li><a href="" class="fa fa-chevron-right"> &nbsp; </a></li>
            <li><a href="" class="fa fa-chevron-right"> &nbsp; </a></li>
           </div>
		   <div class="column">
		    <a href="#"><h4 style="color: #000033;  text-decoration: underline;">Industry  Sectors</h4></a>
            <a href="IT-Industries.php" class="fa fa-chevron-right"> &nbsp; Information Technology</a>
		    <a href="oil-&-gas-industries.php" class="fa fa-chevron-right"> &nbsp; The Oil and Gas Industry</a>
			<a href="Electrical-and-Electronics-Industry.php" class="fa fa-chevron-right"> &nbsp; Electrical and Electronics Industry</a>
			<a href="Engineering-Industry.php" class="fa fa-chevron-right"> &nbsp; Engineering Industry</a>
			<a href="FMCG-Industry.php" class="fa fa-chevron-right"> &nbsp; FMCG Industry </a>    
           </div>
		   <div class="column">
		    <a href="#"><h4 style="color: #000033;  text-decoration: underline;"></h4></a><br>
			<a href="Healthcare-sector.php" class="fa fa-chevron-right"> &nbsp; Healthcare Sector</a>
            <a href="Hospitality-Industry.php" class="fa fa-chevron-right"> &nbsp; Hospitality Industry</a>
		    <a href="Logistics-Industry.php" class="fa fa-chevron-right"> &nbsp; Logistics Industry</a>
			<a href="Marine-&-Shipping-Industry.php" class="fa fa-chevron-right"> &nbsp; Marine & Shipping Industry</a>
			<a href="Mine-&-Refinery-Industry.php" class="fa fa-chevron-right"> &nbsp; Mine & Refinery Industry</a>
           </div>
		  </div>
		</ul>-->
        </li>
		<li class="dropdown"  id="" >
		<a href="" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Job Openings<span class="glyphicon glyphicon-menu-down" aria-hidden="true" style="font-size: 14px;margin-left: 5px;"></span>
			</a>
		<ul class="dropdown-menu">
		<div class="row">
			  <div class="column">
				  <span class="fa fa-chevron-right"><a href="jobopenings-demo.php"  > Domestic - Current Open Positions  </a></span>
		</div>
			<div class="column">
		  <span class="fa fa-chevron-right"><a href="jobopenings-international.php"  > International - Current Open Positions  </a></span>
			  </div>
		</div>
		</ul>
		</li>
		<!--<li ><a href="http://jobs.talensetustaffing.com/" target="_blank">Job Openings</a></li>-->
    <!--<li ><a href="approach.php">Approach</a></li>  
		<li ><a href="career.php">Careers</a></li>-->
        <li ><a href="contact-us.php">Contact Us</a></li>
    <!--<li ><a href="frequently-ask-questions.php">FAQ</a></li>-->
       <li ><a href="http://blog.talensetustaffing.com/" target="_blank">Blog</a></li>
       <li ><a href="enquiry.php">Enquiry</a></li>
       <!-- <li ><a href="faq.php">FAQ</a></li>-->
      </ul>
    </div><!-- /.navbar-collapse -->
    </div>
  </div><!-- /.container-fluid -->
</nav>  
  
    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel"> 
      <!-- Wrapper for slides -->
      <div class="carousel-inner" role="listbox">
        <div class="item active">
          <div class="fill2" alt="Hotel Shreyas" style="background-image:url('images/internalBanner/aboutus-banner.jpg');" alt="ITES Staffing Services | ITES Staffing Company | Agency | Pune | Mumbai|Bengaluru" title="ITES Staffing Services | ITES Staffing Company | Agency | Pune | Mumbai| Bengaluru"></div>
          <div class="overBg"></div>
        </div>
      </div>
    </div>
  </div>
</header>

<section>
 <div class="outerBreadcrumb">
   <div class="container">
	<nav aria-label="breadcrumb" role="navigation">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
        <li class="breadcrumb-item"><a href="industries-landing.php">Industries</a></li>
        <li class="breadcrumb-item active" aria-current="page">ITES</li>
       </ol>
    </nav>
  </div>  
</div>
</section>

<section class="internalPageWrap">
<div class="container">
<div class="row">
<div class="col-md-12">
<h1>ITES</h1>
The information technology-enabled services is a sister branch of IT industry. It is one of the largest industries in India with around 33-50% employees of total workforce working in this industry.  It includes a wide range of information technology operations to improve the effectiveness of the organization. India has a huge market for ITES, as there is an availability of cheaper and talented workforce. The tech giants do not go for the developed nations for these services, as it will not be cost effective for them. Several <strong>ITES staffing services</strong> in India provide different candidates for this rapidly growing industry. Even though there is an abundance of the workforce in this industry, it demands something more than that.

<h3><i class="fa fa-industry" aria-hidden="true"></i>Industry Needs</h3> 
<ul class="aboutList">
<li>Many candidates are graduates and lack a thorough knowledge of the industry requirements. </li> 
<li>Many candidates lack good communication skill and soft skills.</li>
<li>There is quantity over quality.</li>
<li>The ITES staffing companies need to provide industry ready candidates who are familiar with industry skills.</li>
<li>Today, the ITES companies are looking for tech-savvy as well as multi-skilled people.</li>
</ul>

<h3><i class="fa fa-industry" aria-hidden="true"></i>The Solution</h3> 
<ul class="aboutList">
<li>The solution is Talensetu. Talensetu has correctly recognized the real problem in ITES industry and has started working on it.</li>
<li>We at Talensetu run an orientation program for the candidates which are selected by our clients. The candidates attend this  program which is specifically designed for the undergraduates/graduates/pass outs/students if the client expresses the requirement for it.</li>
<li>This orientation program is designed for keeping in mind the industry requirements. We know what the industries demand and we try to fulfill it with our rigorous efforts.</li> 
<li>In orientation program, we try to provide our candidates all the necessary skills required for the industry.</li>
<li>It is not just about technical skills. We take care of their communication skills, soft skills so that when they step into the market they will be ready to press the ‘GO’ button.</li>
<li>We understand the scope and growing demands of ITES industry. We are aware of the diverse needs of companies including workforce and payroll management.  </li>
<li>Though every company can handle their payroll efficiently, if they outsource it to an experienced company, they save on time and money. The client can focus on their core business development. The activities like accounts, inventory, and calculations of tax require experience and vetted workforce. We provide payroll management service for all sorts companies.</li>
<li>The tasks regarding the taxes are quite difficult. We make sure that after our efforts you do not need to take a second look at these matters.</li> 
<li>Other tasks like the keeping salary records, leaves, payable days, employee state insurance (ESI) require significant workforce and experience. Talensetu manages all these things so that you can focus on the growth of your business.</li>
<li>We always try to deliver best for our clients whether if it is staffing or payroll management. With our agency offices in Pune , Mumbai and Bengaluru we offer faster services to our clients spread across various states.</li>
</ul>

ITES industry is growing fast. It has huge potential and bright future. India has proved to be a promising destination for this industry. And Talensetu will help this industry only go further.
</div>



</div>
</div>
</section>


<footer>
<div class="topFooter">
    <div class="container">
    <div class="footerNav">
    <div class="col-md-2 col-sm-2 col-xs-12">
    <ul class="footerLink">
    <li><a href="index.php">Home &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  </a></li>
    <li><a href="about-us.php">About Us &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </a></li>
	<li><a href="contact-us.php">Contact Us&nbsp;&nbsp;</a></li>
	<li><a href="http://blog.talensetustaffing.com/" target="_blank">Blog&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </a></li>
	<li><a href="enquiry.php">Enquiry&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
	<li><a href="privacy_policy.php">Privacy Policy </a></li>
    </ul>
    </div>
    <div class="col-md-3 col-sm-3 col-xs-12">
	
	
	
    <ul class="footerLink">
           	<li><a href="services-landing.php"><strong>Domestic Services</strong></a></li>
		<li><a href="Manpower-Supply-Services.php">Manpower Supply Services </a></li>
		<li><a href="payroll-outsourcing-services.php">Payroll Services</a></li>
		<li><a href="contract-staffing.php">Contract to Hire </a></li>
		<li><a href="national-apprenticeship-promotion-scheme-naps.php">NAPS </a></li>
		<li><a href="facility-management-housekeeping-services-pune.php">Facility Management Services</a></li>
			
			
				  
			
			
 
  <!--      <li><a href="temporary-staffing-services.php">Temporary Staffing</a></li>-->
  <!--      <li><a href="permanent-staffing.php">Permanent Staffing </a></li>-->
	
		<!--<li><a href="contract-to-hire-staffing.php">Manpower Supply </a></li>-->
		<!--<li><a href="recruitment-process-outsourcing.php">Recruitment Process Outsourcing</a></li>-->
	
	
    </ul>
    </div>
    <div class="col-md-3 col-sm-3col-xs-12">
	
    <ul class="footerLink">
        <li><a href="industries-landing.php"><strong>Domestic Industry Sectors </strong></a></li>
    	<li><a href="engineering-manufacturing-staffing-services.php">Engg. Manufacturing</a></li>
    	<li><a href="retail-staffing-services.php">Retail Industry</a></li>	
    	<li><a href="it-staffing-services.php">IT Industry&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
    	<li><a href="bfsi-staffing-services.php">BFSI Industry</a></li>
    		<li><a href="telecom-staffing-services.php">Telecom Industry</a></li>
    
    	
       
        <!--<li><a href="ITeS-BPO.php">ITeS BPO  </a></li>-->
        
        
		
	
		<!--<li><a href="sales-and-account-manager-recruitment-staffing-agency.php"> Sales & Account Manager </a></li>-->
		<!--<li><a href="field-sales-officer-recruitment-staffing-agency.php"> Field Sales Officer  </a></li>-->
		<!--<li><a href="retail-associate-recruitment-staffing-agency.php">Retail Associate </a></li>-->
		<!--<li><a href="BPO-executive-recruitment-staffing-agency.php">BPO Executive </a></li>-->
		
		
   
   </ul>
    </div>
	
	
	<div class="col-md-4 col-sm-3 col-xs-12">
    <ul class="footerLink">
    	<li><a href="International-Recruitment.php"><strong>International Recruitment </strong></a></li>
		<li><a href="Overseas-Training.php">Overseas Training</a></li>
		<li><a href="Categories-of-Technician.php"> Categories of Technician</a></li>
		<li><a href="Categories-of-Recruitment.php">Categories of Recruitment</a></li>
        <li> <a href="Civil-Construction-Industry.php">Civil Construction Industry</a> </li>
	    <li> <a href="Oil-and-Gas-Industry.php"> Oil and Gas Industry </a></li>
		<li><a href=" Oil-Fields-and-Refinery-Industry.php"> Oil Fields and Refinery Industry</a></li>
		<li> <a href="Petrochemical-&-Process-Industry.php">Petrochemical & Process Industry</a></li>
		
		<li> <a href="Manufacturing-Industry.php"> Manufacturing Industry</a></li>
		
		<li> <a href="Infrastructure-Industry.php"> Infrastructure Industry</a></li>
		<li> <a href="Power-and-Utility-Industry.php">Power and Utility Industry</a></li>
		<li><a href="Medical-and-Hospital-Industry.php">Medical and Hospital Industry</a></li>
		<li> <a href="Information-Technology.php"> Information Technology</a></li>
		<li> <a href="Steel-Fabrication-Industry.php">Steel Fabrication Industry</a>
        </li>
    </ul>
    </div>
		
		 
		
		
    </div>
		<div class="col-md-12 col-sm-12 col-xs-12">
        <ul class="socialLinks">
          <li><a href="https://www.facebook.com/Talensetustaffing/" target="_blank" title="Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
          <li><a href="https://twitter.com/talensetu" title="Twitter" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
          <li><a href="https://in.linkedin.com/company/talensetu-staffing" target="_blank" title="Linkedin"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
          <li><a href="https://www.youtube.com/channel/UCi7msa0gd7OqewUf-9HUo3Q/featured" title="Youtube" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
        </ul>
      </div>
	</div><br>
	
	
	
	


<!--<div class="topFooter">
  <div class="container">
     <div class="col-md-2 col-sm-12 col-xs-12">
    <ul class="footerLink">
        <li><a href="index.php">Home</a></li>
        <li><a href="about-us.php">About Us</a></li>
	    <li><a href="contact-us.php">Contact Us</a></li>
	    <li><a href="blog.php">Blog   </a></li>
		<li><a href="enquiry.php">Enquiry</a></li>
    </ul>
    </div>
	 <div class="col-md-4 col-sm-12 col-xs-12">
    <ul class="footerLink">
	    <li><a href="services-landing.php"><strong>Services  </strong></a></li>
        <li><a href="temporary-staffing-services.php">Temporary Staffing</a></li>
        <li><a href="permanent-staffing.php">Permanent Staffing </a></li>
		<li><a href="contract-staffing.php">Contract Staffing  </a></li>
		<li><a href="contract-to-hire-staffing.php">Contract to Hire </a></li>
		<li><a href="recruitment-process-outsourcing.php">Recruitment Process Outsourcing (RPO)</a></li>
		<li><a href="payroll-outsourcing-services.php">Payroll Services  </a></li>
        <li><a href="international-recruitment-services.php">International Recruitment Services</a></li>
    </ul>
    </div>
	 <div class="col-md-4 col-sm-12 col-xs-12">
    <ul class="footerLink">
	    <li><a href="industries-landing.php"><strong>Industry Sectors </strong></a></li>
        <li><a href="it-staffing-services.php">IT Staffing Services  </a></li>
        <li><a href="ites-staffing-serivces.php">ITES Staffing Services  </a></li>
        <li><a href="bfsi-staffing-services.php">BFSI Staffing Services </a></li>
        <li><a href="retail-staffing-services.php"> Retail Staffing Services</a></li>	
		<li><a href="telecom-staffing-services.php">Telecom Staffing Services</a></li>	
		<li><a href="engineering-manufacturing-staffing-services.php">Engg. Manufacturing Staffing Services</a></li>
    </ul>
    </div>
       <div class="col-md-2 col-sm-12 col-xs-12">
        <ul class="socialLinks">
          <li><a href="https://www.facebook.com/Talensetustaffing/" target="_blank" title="Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
          <!--<li><a href="#" title="Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
          <li><a href="https://in.linkedin.com/company/talensetu-staffing" target="_blank" title="Linkedin"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
          <!--<li><a href="#" title="Google Plus"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
        </ul>
      </div>
    
  </div>
</div>-->
<div class="bottomFooter">
  <div class="container">
    <div class="row">
      <div class="col-md-8 col-sm-4 col-xs-12">
        <h5>Copyright © 2018 Talensetu Services Pvt. Ltd. </h5>
        <h5 class="power"> </h5>
      </div>
      <div class="col-md-4 col-sm-4 col-xs-12">
        <h5 class="best">Best viewed in IE 10+, Firefox 20+, Chrome , Safari5+, Opera12+ </h5>
      </div>
      
    </div>
  </div>
</div>



<a href="#" class="enqBtn"  data-toggle="modal" data-target="#myModal">Employer & Candidate Enquiry</a>
<div class="modal fade bs-example-modal-lg formModal" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button aria-label="Close" data-dismiss="modal" class="close" type="button"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Enquiry</h4>
      </div>
      <div class="modal-body">
     <div class="selectFormType">
          <label class="radio-inline">
            <input type="radio" name="inlineRadioOptions" id="employer" value="student" checked="checked">
            <strong style="color: #004caf ; font-size: 18px;">Business Enquiry</strong> </label>
          <label class="radio-inline">
            <input type="radio" name="inlineRadioOptions" id="candidate" value="company">
             <strong style="color: #004caf ; font-size: 18px;">Job Enquiry </strong></label>
        </div>

        <div class="row" id="enquiryForm">
          <p class="popp"><span>*</span> Fields are mandatory</p>
          
          <form class="form-inline" name="employer" method="post"  action="employer-action.php" id="employer">
            <div class="validateContainer">
              <div class="employerForm">
                <div class="col-md-6 col-sm-12">
                  <div class="form-group">
                    <!--<label for="Name">Name<span>*</span></label>-->
                    <div class="validateField">
                      <input type="text" class="form-control validateRequired validateAlphaonly" placeholder="Name*" id="ename" name="ename" maxlength="50">
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-sm-12">
                  <div class="form-group">
                    <!--<label for="companyOrganisation">Company/Organisation</label>-->
                    <div class="validateField">
                      <input type="text" class="form-control" id="ecompanyOrganisation" placeholder="Company/Organisation" name="ecompanyOrganisation">
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-sm-12">
                  <div class="form-group">
                    <!--<label for="Designation">Designation</label>-->
                    <div class="validateField">
                      <input type="text" class="form-control" placeholder="Designation" id="edesignation" name="edesignation">
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-sm-12">
                  <div class="form-group">
                    <!--<label for="Email">Email<span>*</span></label>-->
                    <div class="validateField">
                      <input type="email" class="form-control validateRequired validateEmail" placeholder="Email*" id="eemail" name="eemail" maxlength="50">
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-sm-12">
                  <div class="form-group">
                    <!--<label for="Phone">Phone<span>*</span></label>-->
                    <div class="validateField">
                      
                      <input type="text" class="form-control validateRequired validateNumber validateMobileNoLimit" placeholder="Phone*" maxlength="10" id="ephone" name="ephone" maxlength="10">
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-sm-12">
                  <div class="form-group">
                    <!--<label for="Course">Course</label>-->
                    <div class="validateField">
                      <select class="form-control" id="ecourse" name="ecourse">
                        <option value="">-------- Interested in ---------</option>
                        <option value="Manpower Supply Services">Manpower Supply Services</option>
                        <option value="Payroll Outsourcing Servicess">Payroll Outsourcing Services</option>
                        <option value="Contract to Hire Staffing">Contract to Hire Staffing</option>
                        <option value="National Employability Promotion Scheme (NAPS)">National Employability Promotion Scheme (NAPS)</option>
                        <option value="Facility Management Services">Facility Management Services</option>
      <!--                  <option value="Contract to Hire Staffing">Contract to Hire Staffing</option>-->
      <!--                  <option value="Temporary Staffing Services">Temporary Staffing Services</option>-->
						<!--<option value="Permanent Staffing Services">Permanent Staffing Services</option>-->
						<!--<option value="Contract Staffing Services">Contract Staffing Services</option>-->
						<!--<option value="Contract to Hire Services">Contract to Hire Services</option>-->
						<!--<option value="RPO Services">RPO Services</option>-->
      <!--                  <option value="Payroll Services">Payroll Services</option>-->
						<option value="International Recruitment Service">International Recruitment Services</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-sm-12">
                  <div class="form-group">
                    <!--<label for="CMessage">Your Message</label>-->
                    <div class="validateField">
                      <textarea class="form-control" rows="3" placeholder="Your Message" id="emessage" name="emessage" maxlength="250"></textarea>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-sm-12">
                  <div class="form-group">
                    <!--<label for="spamCode" class="control-label">Enter Spam code</label>-->
                    <div class="validateField">
                    <div class="spamCode spamCode2">
                      <img src='./images/verification/7.gif' alt=''><img src='./images/verification/E.gif' alt=''><img src='./images/verification/A.gif' alt=''><img src='./images/verification/5.gif' alt=''><img src='./images/verification/B.gif' alt=''>                      <input type="hidden" name="espamcodehidden1" id="espamcodehidden1" value="7EA5B" />
					  
                                            
                    </div>
                    <div class="spamCode1">
                      <input type="text" class="form-control validateRequired validateSpams" placeholder="Enter spam code" name="eSpamCode" id="eSpamCode">
                    </div>
                    <div class="clearfix"></div>
                    </div>
                  </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-12 col-sm-12 text-right">
                  <button type="submit" class="btn btn-default  checkValidationBtn">Submit</button>
                  <button type="reset" class="btn btn-default">Reset</button>
                </div>
              </div>
            </div>
          </form>
   
          <form class="form-inline" name="candidate" method="post" action="candidate-action.php" id="candidate" enctype="multipart/form-data">
            <div class="validateContainer">
              <div class="candidateForm">
                <div class="col-md-6 col-sm-12">
                  <div class="form-group">
                    <!--<label for="CName">Name</label>-->
                    <div class="validateField">
                      <input type="text" class="form-control validateRequired  validateAlphaonly" placeholder="Name*" id="cname" name="cname" maxlength="50">
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-sm-12">
                  <div class="form-group">
                    <!--<label for="CName">Email Id</label>-->
                    <div class="validateField">
                      <input type="email" class="form-control validateRequired validateEmail" placeholder="Email Id*" id="cemail" name="cemail" maxlength="50">
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-sm-12">
                  <div class="form-group">
                    <!--<label for="Mobile">Mobile No.</label>-->
                    <div class="validateField">
                      <input type="tel" class="form-control validateNumber validateMobileNoLimit" placeholder="Mobile No."  id="cphone" name="cphone" maxlength="10">
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-sm-12" hidden>
                  <div class="form-group">
                    <!--<label for="Course">Choose Speciality</label>-->
                    <div class="outerChoose">
                      <div class="validateField">
                        <select class="form-control" id="cspeciality" name="cspeciality">
                          <option value="">-------- Choose Speciality ---------</option>
                          <option value="Not Mentionede" selected>Not Mentioned</option>
                          <option value="Accounting Finance">Accounting/Finance</option>
                          <option value="Administrative">Administrative</option>
                          <option value="Banking">Banking</option>
                          <option value="Funds Investments">Funds/Investments</option>
                          <option value="Government Services">Government Services</option>
                          <option value="Healthcare Revenue Cycle Management">Healthcare Revenue Cycle Management</option>
                          <option value="Human Resources">Human Resources</option>
                          <option value="Legal Attorney">Legal - Attorney</option>
                          <option value="Legal Paralegal">Legal - Paralegal</option>
                          <option value="Legal Support">Legal - Support</option>
                          <option value="Marketing">Marketing</option>
                          <option value="Pharma Clinical Research">Pharma/Clinical Research</option>
                          <option value="Public Accounting">Public Accounting</option>
                          <option value="Sales">Sales</option>
                          <option value="Tax">Tax</option>
                          <option value="Technology">Technology</option>
							<option value="International Recruitment Services">International Recruitment Services</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-sm-12">
                  <div class="form-group">
                    <!--<label for="Qualification">Qualification</label>-->
                    <div class="validateField">
                      <input type="text" class="form-control" placeholder="Qualification" id="cqualification" name="cqualification">
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-sm-12">
                  <div class="form-group">
                    <!--<label for="Experience">Experience</label>-->
                   <!-- <div class="validateField">
                      <select class="form-control" id="cexperience" name="cexperience">
                        <option value="">-------- Experience ---------</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                      </select>
                    </div>-->
					  <div class="validateField">
                      <input type="tel" class="form-control validateNumber " placeholder="Experience"  id="cexperience" name="cexperience" maxlength="2">
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-sm-12">
                  <div class="form-group">
                    <!--<label for="Comments">Comments</label>-->
                    <div class="validateField">
                      <textarea class="form-control" placeholder="Comments" rows="3" id="ccomments" name="ccomments"></textarea>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-sm-12">
                  <div class="form-group">
                    <label for="file" class="col-sm-4 control-label">Upload CV </label>
            
                      <input type="file" class="form-control validUpload" name="uploaded_file" id="uploaded_file" accept="application/msword,application/pdf "  data-msg-accept="Please upload .doc or .pdf file">
                      <p class="help-block" style="padding-left: 0;">Please upload .doc  or .pdf file.</p>
                  </div>
                </div>
                <div class="col-md-6 col-sm-12">
                  <div class="validateField">
                  <div class="form-group">
                   
                    <!--<label for="spamCode" class="control-label">Enter Spam code</label>-->
                    <div class="spamCode spamCode2">
                      <img src='./images/verification/7.gif' alt=''><img src='./images/verification/E.gif' alt=''><img src='./images/verification/A.gif' alt=''><img src='./images/verification/5.gif' alt=''><img src='./images/verification/B.gif' alt=''>                      <input type="hidden" name="spamcodehidden" id="spamcodehidden" value="7EA5B" />
                                            
                    </div>
                    <div class="spamCode1">
                      <input type="text" class="form-control validateRequired validateSpam" placeholder="Enter spam code" name="CSpamCode" id="CSpamCode">
                    </div>
                  </div>
                  </div>
                </div>
                <div class="col-md-6 col-sm-12">
                  <button type="submit" name="cSubmit" class="btn btn-default checkValidationBtn ">Submit</button>
                  <button type="reset" name="cReset" class="btn btn-default">Reset</button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="./js/jquery.validate.js"></script>
<script>
  	$(document).ready(function() { 
	

		jQuery.validator.addMethod("emailValidation", function(value, element) 
		{
    		return this.optional(element) || /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/i.test(value);
		}, "Invalid email id");	
		
		jQuery.validator.addMethod("lettersonly", function(value, element) 
		{
    		return this.optional(element) || /^[a-z\s]+$/i.test(value);
		}, "Only alphabetical characters");	
		
		jQuery.validator.addMethod("GovernorshipYear", function(value, element) 
		{
    		return this.optional(element) || /^[0-9 -]+$/i.test(value);
		}, "Please enter valid Year of Governorship");	
	
		$("#career").validate({ 
		rules: { 
			Name:{
				required:true,
				lettersonly: true
			},
			Mobile:{
				required:true,
				number : true,
				minlength:10
			},
			Email:{
				required:true,
				emailValidation:true,
			},
			Qualification:{
				required:true,
			},
			Experience:{
				required:true,
			},
			CourseName:{
				required:true,
			},
		
			SpamCode:{
				required:true,
				equalTo:'#careerspamchk'
			},
		},
			messages: {
				Name: {
					required : "This field is required",
					lettersonly : "Please enter valid name",
				},
				MobileNo:{
					number: "Please enter digits only",
					minlength : "Please enter at-least 10 digits",
				},
				Email:{
						required: "Please enter email id ",
						emailValidation: "Please enter valid email id",
				},
				Qualification:{
						required:"This field is required",
						lettersonly : "Please enter valid Course name",
				},
				Experience:{
						required:"This field is required",
						lettersonly : "Please enter valid Course name",
				},
				CourseName:{
						required:"This field is required",
				},
				SpamCode: {
						required:"This field is required",
				  		equalTo : "Please enter correct Spam Code"
				},
			},
		});
	});
</script>
</footer>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/bootstrap.min.js"></script>
<script src="js/validation/jquery.validate.min.js"></script>
<script src="js/validation/additional-methods.min.js"></script>
<script src="js/validation/checkvalidation.js"></script>
<script src="js/validation/checkvalidation-candidate.js"></script>
<script src="js/validation/checkvalidation-employer.js"></script>
<script src="js/allscript.js"></script>
</body>
</html>
